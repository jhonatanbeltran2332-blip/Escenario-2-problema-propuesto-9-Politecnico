import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DecimalFormat;
import java.text.Normalizer;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Proyecto Módulo — Primera Entrega
 *
 * Clase: GenerateInfoFiles
 *
 * Responsabilidad: Generar archivos de prueba (planos CSV con separador ';') que
 * servirán como entrada del programa principal del proyecto. No solicita
 * información al usuario; al ejecutarse, crea automáticamente:
 *
 * 1) products.csv — catálogo de productos (ID;Nombre;PrecioPorUnidad)
 * 2) salesmen.csv — información de vendedores (TipoDocumento;NumeroDocumento;Nombres;Apellidos)
 * 3) Una carpeta sales/ con un archivo por vendedor, con el siguiente formato:
 *    - Primera línea: TipoDocumentoVendedor;NumeroDocumentoVendedor
 *    - Resto de líneas: IDProducto;CantidadVendida
 *
 * Requisitos cubiertos:
 *  - createProductsFile(int productsCount)
 *  - createSalesManInfoFile(int salesmanCount)
 *  - createSalesMenFile(int randomSalesCount, String name, long id)
 *
 * Notas de estilo:
 *  - Java 8 compatible.
 *  - Buenas prácticas de nombramiento y espaciado.
 *  - Documentación Javadoc en métodos públicos.
 *
 * Extra opcional implementado:
 *  - Detección simple de incoherencias antes de escribir ventas (por ejemplo, que el ID de producto exista y que las cantidades sean > 0).
 *  - Posibilidad de generar más de un archivo por vendedor (controlado por la constante MULTI_SALES_FILES_PER_SELLER).
 */
public class GenerateInfoFiles {

    // ==== Parámetros de generación (ajustables) ====
    private static final int DEFAULT_PRODUCTS_COUNT = 50;        // cantidad de productos
    private static final int DEFAULT_SALESMEN_COUNT = 15;         // cantidad de vendedores
    private static final int MIN_SALES_PER_SELLER = 10;           // ventas mínimas por archivo de vendedor
    private static final int MAX_SALES_PER_SELLER = 40;           // ventas máximas por archivo de vendedor
    private static final int MIN_QTY_PER_LINE = 1;                // cantidad mínima por ítem vendido
    private static final int MAX_QTY_PER_LINE = 12;               // cantidad máxima por ítem vendido
    private static final int MULTI_SALES_FILES_PER_SELLER = 1;    // poner >1 para generar varias ventas por vendedor (extra)

    private static final String OUT_DIR = "data";                // carpeta base
    private static final String SALES_DIR = OUT_DIR + "/sales";   // carpeta de archivos de ventas por vendedor

    private static final String PRODUCTS_FILE = OUT_DIR + "/products.csv";
    private static final String SALESMEN_FILE = OUT_DIR + "/salesmen.csv";

    // Tipos de documento posibles
    private static final String[] DOC_TYPES = {"CC", "CE", "NIT"};

    // Datos base para generar nombres/apellidos y productos
    private static final String[] FIRST_NAMES = {
            "Juan", "Ana", "Luis", "María", "Pedro", "Lucía", "Camila", "Sofía", "Carlos", "Andrés",
            "Valentina", "Diana", "Jorge", "Felipe", "Daniela", "Sebastián", "Laura", "Marta",
            "Carolina", "Paula"
    };

    private static final String[] LAST_NAMES = {
            "García", "Rodríguez", "Martínez", "López", "Hernández", "Pérez", "Gómez", "Díaz",
            "Sánchez", "Ramírez", "Torres", "Castro", "Vargas", "Rojas", "Moreno", "Jiménez"
    };

    private static final String[] PRODUCT_BASE_NAMES = {
            "Guantes", "Casco", "Botas", "Gafas", "Overol", "Pantalón", "Chaqueta", "Cinturón",
            "Camisa", "Pechera", "Protector Auditivo", "Mascarilla", "Rodilleras", "Coderas",
            "Impermeable", "Linterna", "Arnés", "Capucha", "Camiseta", "Maletín"
    };

    private static final Random RNG = new Random(42); // Semilla fija para reproducibilidad

    /** Producto simple en memoria. */
    private static class Product {
        final String id;      // por ejemplo, P001
        final String name;    // nombre del producto
        final int unitPrice;  // precio por unidad en enteros (p.ej. 18000)
        Product(String id, String name, int unitPrice) {
            this.id = id;
            this.name = name;
            this.unitPrice = unitPrice;
        }
    }

    /** Vendedor simple en memoria. */
    private static class Salesman {
        final String docType;      // CC | CE | NIT
        final long docNumber;      // número de documento
        final String firstNames;   // nombres
        final String lastNames;    // apellidos
        Salesman(String docType, long docNumber, String firstNames, String lastNames) {
            this.docType = docType;
            this.docNumber = docNumber;
            this.firstNames = firstNames;
            this.lastNames = lastNames;
        }
    }

    // Catálogos generados para garantizar coherencia entre archivos
    private static final List<Product> PRODUCTS = new ArrayList<>();
    private static final List<Salesman> SALESMEN = new ArrayList<>();

    public static void main(String[] args) {
        try {
            prepareOutputFolders();

            // 1) Generar productos y vendedores (catálogos coherentes)
            createProductsFile(DEFAULT_PRODUCTS_COUNT);
            createSalesManInfoFile(DEFAULT_SALESMEN_COUNT);

            // 2) Generar archivos de ventas por vendedor
            for (Salesman s : SALESMEN) {
                for (int i = 1; i <= MULTI_SALES_FILES_PER_SELLER; i++) {
                    int lines = randomBetween(MIN_SALES_PER_SELLER, MAX_SALES_PER_SELLER);
                    String safeName = toFileSafe(s.firstNames + "_" + s.lastNames);
                    String fileName = String.format(Locale.ROOT,
                            "%s/ventas_%s_%d_%02d.csv", SALES_DIR, s.docType, s.docNumber, i);
                    createSalesMenFile(lines, safeName, s.docNumber, fileName, s.docType);
                }
            }

            System.out.println("[OK] Archivos generados correctamente en la carpeta '" + OUT_DIR + "'.");
        } catch (Exception ex) {
            System.err.println("[ERROR] No fue posible generar los archivos: " + ex.getMessage());
            ex.printStackTrace();
        }
    }

    /** Crea carpetas base de salida. */
    private static void prepareOutputFolders() throws IOException {
        Files.createDirectories(Paths.get(OUT_DIR));
        Files.createDirectories(Paths.get(SALES_DIR));
    }

    /**
     * Genera el archivo de productos con datos pseudoaleatorios y lo guarda en products.csv.
     * Formato: ID;Nombre;PrecioPorUnidad
     * @param productsCount cantidad de productos a generar.
     */
    public static void createProductsFile(int productsCount) throws IOException {
        PRODUCTS.clear();
        List<String> lines = new ArrayList<>();

        for (int i = 1; i <= productsCount; i++) {
            String id = String.format(Locale.ROOT, "P%03d", i);
            String baseName = PRODUCT_BASE_NAMES[RNG.nextInt(PRODUCT_BASE_NAMES.length)];
            String variant = variantLabel();
            String name = baseName + (variant.isEmpty() ? "" : (" " + variant));
            int unitPrice = randomBetween(8000, 250000); // precio por unidad en pesos

            PRODUCTS.add(new Product(id, name, unitPrice));
            lines.add(String.join(";", id, name, String.valueOf(unitPrice)));
        }

        writeAllLines(PRODUCTS_FILE, lines);
    }

    /**
     * Genera el archivo de información de vendedores y lo guarda en salesmen.csv.
     * Formato: TipoDocumento;NumeroDocumento;Nombres;Apellidos
     * @param salesmanCount cantidad de vendedores a generar.
     */
    public static void createSalesManInfoFile(int salesmanCount) throws IOException {
        SALESMEN.clear();
        List<String> lines = new ArrayList<>();

        for (int i = 0; i < salesmanCount; i++) {
            String docType = DOC_TYPES[RNG.nextInt(DOC_TYPES.length)];
            long docNumber = randomDocumentNumber();
            String first = FIRST_NAMES[RNG.nextInt(FIRST_NAMES.length)];
            String last = LAST_NAMES[RNG.nextInt(LAST_NAMES.length)];

            // posibilidad de dos nombres / dos apellidos
            if (RNG.nextBoolean()) first += " " + FIRST_NAMES[RNG.nextInt(FIRST_NAMES.length)];
            if (RNG.nextBoolean()) last += " " + LAST_NAMES[RNG.nextInt(LAST_NAMES.length)];

            SALESMEN.add(new Salesman(docType, docNumber, first, last));
            lines.add(String.join(";", docType, String.valueOf(docNumber), first, last));
        }

        writeAllLines(SALESMEN_FILE, lines);
    }

    /**
     * Genera un archivo de ventas para un vendedor dado. La primera línea contiene la
     * identificación del vendedor y las siguientes líneas registran ventas de un producto por línea.
     * Formato:
     *  - Línea 1: TipoDocumentoVendedor;NumeroDocumentoVendedor
     *  - Líneas siguientes: IDProducto;CantidadVendida
     * @param randomSalesCount número de líneas de venta a generar (>= 1)
     * @param name nombre del vendedor (solo para formar nombre de archivo legible)
     * @param id número de documento del vendedor
     * @param outputFile ruta del archivo a generar
     * @param docType tipo de documento del vendedor
     */
    public static void createSalesMenFile(int randomSalesCount, String name, long id,
                                          String outputFile, String docType) throws IOException {
        if (PRODUCTS.isEmpty()) {
            throw new IllegalStateException("Primero genere el catálogo de productos.");
        }
        if (randomSalesCount < 1) randomSalesCount = 1;

        List<String> lines = new ArrayList<>();
        lines.add(docType + ";" + id);

        // Seleccionamos productos al azar; se permiten repeticiones para simular múltiples ventas del mismo producto
        for (int i = 0; i < randomSalesCount; i++) {
            Product p = PRODUCTS.get(RNG.nextInt(PRODUCTS.size()));
            int qty = randomBetween(MIN_QTY_PER_LINE, MAX_QTY_PER_LINE);
            // Validaciones simples (extra)
            if (p.unitPrice <= 0 || qty <= 0) {
                // no debería pasar, pero por seguridad se omite la línea inválida
                continue;
            }
            lines.add(p.id + ";" + qty);
        }

        writeAllLines(outputFile, lines);
    }

    // ===== Utilidades =====

    private static void writeAllLines(String file, List<String> lines) throws IOException {
        Path path = Paths.get(file);
        Files.createDirectories(path.getParent());
        try (BufferedWriter w = Files.newBufferedWriter(path, StandardCharsets.UTF_8)) {
            for (int i = 0; i < lines.size(); i++) {
                w.write(lines.get(i));
                if (i < lines.size() - 1) w.newLine();
            }
        }
    }

    private static String variantLabel() {
        // Añade un pequeño descriptor opcional al nombre del producto
        switch (RNG.nextInt(5)) {
            case 0: return "Industrial";
            case 1: return "Pro";
            case 2: return "Econ";
            case 3: return "Ref." + (100 + RNG.nextInt(900));
            default: return "";
        }
    }

    private static long randomDocumentNumber() {
        // Genera números de documento de 7 a 10 dígitos
        long base = (long) Math.pow(10, 6 + RNG.nextInt(4)); // 1e6 a 1e9
        long delta = RNG.nextInt(900_000) + 100_000;         // asegura al menos 6 dígitos de variación
        return base + delta;
    }

    private static int randomBetween(int minInclusive, int maxInclusive) {
        return ThreadLocalRandom.current().nextInt(minInclusive, maxInclusive + 1);
    }

    /** Normaliza cadenas para nombres de archivo. */
    private static String toFileSafe(String s) {
        String normalized = Normalizer.normalize(s, Normalizer.Form.NFD)
                .replaceAll("\\p{InCombiningDiacriticalMarks}+", "");
        return normalized.replaceAll("[^a-zA-Z0-9_\\-]", "_");
    }
}
